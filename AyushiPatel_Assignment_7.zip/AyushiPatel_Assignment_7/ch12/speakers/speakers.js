 $(document).ready(function(){
    $("a").click(function() {
        if(this.title == 'toobin' || this.title == 'sorkin' || this.title == 'chua' || this.title == 'sampson'){  
            var _file= 'json_files/'+this.title+'.json';
           
            $.getJSON(_file, function(data) {
$.each(data, function() {
$.each(this, function(key, value) {
$("main").html(
"<h1>"+ value.title +"</h1><img src='"+ value.image +"' alt=''/> <h2>"+value.month+"<br>"+value.speaker+"</h2><p>"+ value.text+"</p>"
);
});
}); 
});
            
        }
    });
    
});
